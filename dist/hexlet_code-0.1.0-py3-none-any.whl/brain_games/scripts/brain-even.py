#!/usr/bin/env python3

import prompt
import random


def main():
    num = random.randint(1, 99)
    ans = 'yes'

    print("Welcome to the Brain Games!")
    name = prompt.string('May I have your name? ')
    print(f"Hello, {name}")

    print("Answer 'yes' if the number is even, otherwise answer 'no'")
    for i in range(1, 4):
        print(f"Question: {num}")
        if num % 2 == 0:
            ans = 'yes'
        else:
            ans = 'no'
        result = prompt.string('Your answer: ')

        if ans != result:
            print(f"{result} is wrong answer ;(. Correct answer was {ans}. Let's try again, {name}!")
            return

        print("Correct!")

    print("Congratulations, Sam!")
    return


if __name__ == '__main__':
    main()

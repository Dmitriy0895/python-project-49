#!/usr/bin/env python3

import sys
from ..cli import welcome_user


def main():
    welcome_user()


if __name__ == '__main__':
    main()

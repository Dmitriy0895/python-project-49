### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dmitriy0895/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Dmitriy0895/python-project-49/actions)
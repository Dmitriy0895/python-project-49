### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dmitriy0895/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Dmitriy0895/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/bd385665ba9b2f405abf/maintainability)](https://codeclimate.com/github/Dmitriy0895/python-project-49/maintainability)

#!/usr/bin/env python3

import prompt
import random


def games(fn):
    print("Welcome to the Brain Games!")
    name = prompt.string('May I have your name? ')
    print(f"Hello, {name}")

    message = {
        'brain_even': "Answer 'yes' if the number is even, otherwise answer 'no'",
        'brain_calc': "What is the result of the expression?",
        'brain_gcd': "Find the greatest common divisor of given numbers"
    }

    obj = fn()

    for key, val in obj.items():
        print(f"Question: {key}")

        result = prompt.string('Your answer: ')

        if val != result:
            print(f"{result} is wrong answer ;(. "
                  f"Correct answer was {val}. "
                  f"Let's try again, {name}!")
            return

        print("Correct!")

    print(f"Congratulations, {name}!")
    return


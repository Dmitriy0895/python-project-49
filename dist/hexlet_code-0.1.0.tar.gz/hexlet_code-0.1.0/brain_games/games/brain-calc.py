#!/usr/bin/env python3

import brain_games.scripts.fb as fb


def main():
    fb.games(game='brain_calc')


if __name__ == '__main__':
    main()
